from abc import ABC, abstractmethod


class IOCR(ABC):
    @abstractmethod
    def extract_items(self, document_type, extract_items):
        pass


class OCR(IOCR):
    def extract_items(self, document_type, extract_items):
        if document_type == 'D0001':
            extract_items[0]['register_num'] = '8471600680'
            extract_items[0]['name'] = '체크메이트'
            extract_items[0]['representative'] = '최기형'
            extract_items[0]['opening_date'] = '20220101'
            extract_items[0]['issued_date'] = '20220608'

        elif document_type == 'D0002':
            extract_items[0]['relation'] = '본인'
            extract_items[0]['name'] = '조경민'
            extract_items[0]['birth_date'] = '780912'
            extract_items.append({'relation': '배우자',
                                  'name': '김정현',
                                  'birth_date': '801112'})

            # extract_items[1]['relation'] = '배우자'
            # extract_items[1]['name'] = '김정현'
            # extract_items[1]['birth_date'] = '801112'

        return extract_items

