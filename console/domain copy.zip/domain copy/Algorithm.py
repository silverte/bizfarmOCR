from abc import ABC, abstractmethod
from asgiref.sync import sync_to_async
from console.models import DocumentRuleValue


class Algorithm(ABC):
    def __init__(self):
        self.composite = None

    @abstractmethod
    async def set_extract_items(self, document_type):
        pass

    @abstractmethod
    async def set_compare_items(self, document_type):
        pass

    # @sync_to_async
    def set_rule_list(self, document_type):
        print("\nset rule_list from Database")
        temp_list = []

        # model
        # domain_rule = DocumentRule.objects.all().values().filter(document_id=self.document_type)
        rule_values = DocumentRuleValue.objects.all().filter(company_id=1).filter(document_id=document_type) \
            .select_related('document_rule')

        for rule_value in rule_values:
            temp = {}
            temp['document_rule_id'] = rule_value.document_rule_id
            temp['rule_class'] = rule_value.document_rule.rule_class
            temp['rule_type'] = rule_value.document_rule.rule_type
            temp['rule_type_value'] = rule_value.document_rule.rule_type_value
            temp['value1'] = rule_value.value1
            temp['value2'] = rule_value.value2
            temp['value3'] = rule_value.value3
            temp['value4'] = rule_value.value4
            temp['value5'] = rule_value.value5
            temp_list.append(temp)

        self.composite.rule_list = temp_list
        for rule in self.composite.rule_list:
            print(rule)

    def get_instance(self):
        return self.composite
