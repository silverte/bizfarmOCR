from console.domain.Algorithm import Algorithm
from console.domain.DocumentRuleTemplate import DocumentRuleTemplate
from console.domain.OCR import IOCR
from console.domain.Legacy import ILegacy


class FamilyRelation(Algorithm):
    OCR_format = [{'relation': '',  # 관계
                   'name': '',  # 이름
                   'birth_date': '',  # 생년월일
                   }, ]
    Legacy_Format = [{'relation': '',  # 관계
                      'name': '',  # 이름
                      'birth_date': '',  # 생년월일
                      }, ]

    def __init__(self, ocr: IOCR, legacy: ILegacy):
        super().__init__()
        self.ocr = ocr
        self.legacy = legacy
        self.composite = DocumentRuleTemplate()

    async def set_extract_items(self, document_type):
        print("\nset items {}".format(__class__))
        print("set extract_items from OCR")

        # OCR
        self.composite.extract_items = self.ocr.extract_items(document_type, FamilyRelation.OCR_format)
        for extract_item in self.composite.extract_items:
            print(extract_item)

    async def set_compare_items(self, document_type):
        print("\nset compare_items from Legacy")

        # Legacy
        self.composite.compare_items = self.legacy.get_compare_items(document_type, FamilyRelation.Legacy_Format)
        for compare_item in self.composite.compare_items:
            print(compare_item)

    # def set_rule_list(self, document_type):
    #     print("\nset rule_list from Database")
    #
    #     # model
    #     domain_rule = DocumentRule.objects.all().values().filter(document_id=document_type)
    #
    #     self.composite.rule_list = list(domain_rule)
    #     for rule in self.composite.rule_list:
    #         print(rule)
