from abc import ABC, abstractmethod


class ILegacy(ABC):
    @abstractmethod
    def get_compare_items(self, document_type, compare_items):
        pass


class Legacy(ILegacy):
    def get_compare_items(self, document_type, compare_items):
        if document_type == 'D0001':
            compare_items[0]['register_num'] = '8471600680'
            compare_items[0]['name'] = '체크메이트'

        elif document_type == 'D0002':
            compare_items[0]['relation'] = '본인'
            compare_items[0]['name'] = '조경민'
            compare_items[0]['birth_date'] = '780912'
            compare_items.append({'relation': '배우자',
                                  'name': '김정현',
                                  'birth_date': '801112'})

            # compare_items[1]['relation'] = '배우자'
            # compare_items[1]['birth_date'] = '801112'
            # compare_items[1]['name'] = '김정현'

        return compare_items
